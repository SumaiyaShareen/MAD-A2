import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
  FlatList,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Icon from "react-native-vector-icons/MaterialIcons";
import * as ImagePicker from "expo-image-picker";

const ProfileScreen = () => {
  const [user, setUser] = useState({
    name: "",
    email: "",
    phone: "",
    profilePicture: "https://via.placeholder.com/150", // Default placeholder image
  });
  const [isEditing, setIsEditing] = useState(false);

  // Dummy posts for the grid
  const [posts, setPosts] = useState([
    { id: "1", image: "https://img.freepik.com/premium-photo/young-woman-standing-against-yellow-background_1048944-3775534.jpg?semt=ais_hybrid" },
    { id: "2", image: "https://img.freepik.com/premium-photo/young-woman-standing-against-yellow-background_1048944-3775534.jpg?semt=ais_hybrid" },
    { id: "3", image: "https://img.freepik.com/premium-photo/young-woman-standing-against-yellow-background_1048944-3775534.jpg?semt=ais_hybrid" },
    { id: "4", image: "https://img.freepik.com/premium-photo/young-woman-standing-against-yellow-background_1048944-3775534.jpg?semt=ais_hybrid" },
    { id: "5", image: "https://img.freepik.com/premium-photo/young-woman-standing-against-yellow-background_1048944-3775534.jpg?semt=ais_hybrid" },
    { id: "6", image: "https://img.freepik.com/premium-photo/young-woman-standing-against-yellow-background_1048944-3775534.jpg?semt=ais_hybrid" },
  ]);

  // Fetch user data from JSONPlaceholder
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const savedProfile = await AsyncStorage.getItem("userProfile");
        if (savedProfile) {
          setUser(JSON.parse(savedProfile));
        } else {
          const response = await fetch(
            "https://jsonplaceholder.typicode.com/users/1"
          );
          const data = await response.json();
          setUser({
            ...user,
            name: data.name,
            email: data.email,
            phone: data.phone,
          });
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, []);

  // Handle input changes
  const handleInputChange = (name, value) => {
    setUser({ ...user, [name]: value });
  };

  // Save changes to local storage
  const saveChanges = async () => {
    try {
      await AsyncStorage.setItem("userProfile", JSON.stringify(user));
      setIsEditing(false);
    } catch (error) {
      console.error("Error saving user data:", error);
    }
  };

  // Open image picker for profile picture
  const pickProfilePicture = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      alert("Sorry, we need camera roll permissions to make this work!");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      setUser({ ...user, profilePicture: result.assets[0].uri });
    }
  };

  // Render each post in the grid
  const renderPost = ({ item }) => (
    <View style={styles.postContainer}>
      <Image source={{ uri: item.image }} style={styles.postImage} />
    </View>
  );

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Profile</Text>
        <TouchableOpacity onPress={() => setIsEditing(!isEditing)}>
          <Icon
            name={isEditing ? "close" : "edit"}
            size={24}
            color="#000"
          />
        </TouchableOpacity>
      </View>

      {/* Profile Picture and Info */}
      <View style={styles.profileSection}>
        <TouchableOpacity onPress={pickProfilePicture}>
          <View style={styles.profileImageContainer}>
            <Image source={{ uri: user.profilePicture }} style={styles.profileImage} />
            <View style={styles.cameraIconContainer}>
              <Icon name="photo-camera" size={20} color="#fff" />
            </View>
          </View>
        </TouchableOpacity>
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{posts.length}</Text>
            <Text style={styles.statLabel}>Posts</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>1.2K</Text>
            <Text style={styles.statLabel}>Followers</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>500</Text>
            <Text style={styles.statLabel}>Following</Text>
          </View>
        </View>
      </View>

      {/* User Details */}
      <View style={styles.detailsSection}>
        {isEditing ? (
          <View>
            <TextInput
              style={styles.input}
              placeholder="Name"
              value={user.name}
              onChangeText={(text) => handleInputChange("name", text)}
            />
            <TextInput
              style={styles.input}
              placeholder="Email"
              value={user.email}
              onChangeText={(text) => handleInputChange("email", text)}
            />
            <TextInput
              style={styles.input}
              placeholder="Phone"
              value={user.phone}
              onChangeText={(text) => handleInputChange("phone", text)}
            />
            <TouchableOpacity style={styles.saveButton} onPress={saveChanges}>
              <Text style={styles.saveButtonText}>Save Changes</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View>
            <Text style={styles.name}>{user.name}</Text>
            <Text style={styles.bio}>Software Developer | React Native Enthusiast</Text>
            <Text style={styles.email}>{user.email}</Text>
            <Text style={styles.phone}>{user.phone}</Text>
          </View>
        )}
      </View>

      {/* Posts Grid */}
      <FlatList
        data={posts}
        renderItem={renderPost}
        keyExtractor={(item) => item.id}
        numColumns={3}
        style={styles.postsGrid}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
  },
  profileSection: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
  },
  profileImageContainer: {
    position: "relative",
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginRight: 20,
  },
  cameraIconContainer: {
    position: "absolute",
    bottom: 0,
    right: 10,
    backgroundColor: "#3897f0",
    borderRadius: 15,
    padding: 5,
  },
  statsContainer: {
    flexDirection: "row",
    flex: 1,
    justifyContent: "space-around",
  },
  statItem: {
    alignItems: "center",
  },
  statNumber: {
    fontSize: 18,
    fontWeight: "bold",
  },
  statLabel: {
    fontSize: 14,
    color: "#888",
  },
  detailsSection: {
    padding: 16,
  },
  name: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 4,
  },
  bio: {
    fontSize: 14,
    color: "#555",
    marginBottom: 8,
  },
  email: {
    fontSize: 14,
    color: "#555",
    marginBottom: 4,
  },
  phone: {
    fontSize: 14,
    color: "#555",
  },
  input: {
    height: 40,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  saveButton: {
    backgroundColor: "#3897f0",
    padding: 10,
    borderRadius: 8,
    alignItems: "center",
  },
  saveButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  postsGrid: {
    marginTop: 16,
  },
  postContainer: {
    flex: 1,
    margin: 1,
    aspectRatio: 1,
  },
  postImage: {
    flex: 1,
    width: "100%",
    height: "100%",
  },
});

export default ProfileScreen;